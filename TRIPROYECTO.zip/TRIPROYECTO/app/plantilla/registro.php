<?php

ob_start();

?>

<?php
$auto = $_SERVER['PHP_SELF'];

?>
<form id="formregistro" action='index.php' method="GET">
	<label>Usuario</label><input name="usuario" type="text"><br>
	<label>Nombre</label><input name="nombre" type="text"><br>
	<label>Correo electrónico</label><input name="correo" type="text"><br>
	<label>Contraseña</label><input name="password" type="text"><br>
	<label>Estado</label>
		<select name="estado">
			<option value='A'>Activo</option>
			<option value='B'>Bloqueado</option>
			<option value='I'>Desactivado</option>
		</select>
	<br>
	<label>Plan</label>
		<select name="plan">
			<option id="basico" value='0'>Básico</option>
			<option id="pro" value='1'>Profesional</option>
			<option id="premium" value='2'>Premium</option>
			<option id="master" value='3'>Máster</option>		
		</select>
	<br>
	<input type='submit' name='orden' value="Registrar alta">
	<input type='submit' value='Cancelar'>
</form>

<?php

$contenido = ob_get_clean();
include_once "principal.php";
?>