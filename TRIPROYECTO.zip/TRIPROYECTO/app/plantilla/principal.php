<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>CRUD DE USUARIOS</title>
		<link href="web/css/default.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="web/js/funciones.js"></script>
		<script type="text/javascript" src="web/js/jquery.js"></script>
		<script type="text/javascript" src="web/js/funcionesJQUERY.js"></script>
		<link rel="icon" type="image/png" href="web/img/favicono.ico"/>
	</head>
	<body>
		<main id="container">
			<header id="header">
				<h1>MI DISCO EN LA NUBE</h1><h2>Modelo 1.0</h2>
			</header>
			<section id="content">
				<?= $contenido ?>
			</section>
		</main>
		<footer id="piePagina">
			Alberto Fernández Gálvez y Jorge Muñoz Feito - 2º DAW
			<br>
			<img id="copy" src="web/img/copy.png">
		</footer>
	</body>
</html>