var sel;
sel=$(document);
sel.ready(inicializarEventos);

function inicializarEventos(){
	var sel;
	sel=$("");
	sel.focus(reColor);
}

function reColor(){
	$(this).css("color", "red");
}
